<?php
// Appliquer la déclaration stricte des types.
declare(strict_types=1);

/*
    Importez le(s) fichier(s) nécessaire(s).
    Lancez la partie en appelant la fonction principale que vous aurez développé dans le fichier 'pendu/app.php'.
*/
?>